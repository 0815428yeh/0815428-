var canvas = document.getElementById('mycanvas')
var ctx = canvas.getContext('2d')
canvas.width= 500;
canvas.height= 500;

ctx.fillStyle="#fff6d1"
ctx.fillRect(0,0,500,500)

ctx.fillStyle="#39afdd"
ctx.beginPath()
ctx.moveTo(100,0)
ctx.lineTo(300,100)
ctx.lineTo(100,100)
ctx.closePath()
ctx.fill()

ctx.fillStyle="#ffd800"
ctx.beginPath()
ctx.moveTo(100,100)
ctx.lineTo(300,100)
ctx.lineTo(100,300)
ctx.closePath()
ctx.fill()

ctx.fillStyle="#7ccc7c"
ctx.beginPath()
ctx.moveTo(300,300)
ctx.lineTo(100,300)
ctx.lineTo(300,100)
ctx.closePath()
ctx.fill()